#!/bin/bash

#==============================================
#▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
#██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
#██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
#▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
#.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
#Cracked By [!]DNThirTeen
#https://www.facebook.com/groups/L34K.C0de/
#==============================================

clear

echo    "           \033[1;31m[+]==============================[\033[1;33mBSTRD SENDER\033[1;31m]================================[+]"
echo    "           \033[1;35m                         ##############################	"
echo    "           \033[1;31m                         █████▄░▄███▄░████░████▄░████▄░	"
echo    "           \033[1;31m                         ██▄▄█▀░▀█▄▀▀░░██░░██░██░██░▀██	"
echo    "           \033[1;33m                         ██░░██░▄▄▀█▄░░██░░████▀░██░▄██	"
echo    "           \033[1;33m                         █████▀░▀███▀░░██░░██░██░████▀░	"
echo    "           \033[1;35m                         ##############################   "
echo    "           \033[1;35m                         #####CRACKED BY DNThirTeen####   "
echo    "           \033[1;35m                         ###########L34kC0de###########   "
echo    "           \033[1;35m                         ##############################	"
echo    "           \033[1;31m[+]==============================[\033[1;33mSENDER READY\033[1;31m]================================[+]"
echo "\033[0m";
while true; do
   read -p "           Do you wish to Generate SMTP ? (y/n) : " yn
   case $yn in
       [Yy]* ) read -p "           Enter your SMTP Domain ? (example.tld) : " inputname;;
     [Nn]* ) sh "function/run.sh" && exit;;

    esac
    case $inputname in
         $inputname ) read -p "           How Many user ? : " total;;
    esac
    case $total in
         $total ) echo $total >> "function/user_total.txt" && echo $inputname >> "function/domain.txt" && echo "           Generating...." && cd "function" && sleep 3 && php "generate.php" && read -p "           Upload generated csv to admin, Have done ? (y/n) " haha;;
    esac
    case $haha in
         [Yy]* ) cd "../" && sh "function/run.sh" && exit ;;
         [Nn]* ) exit ;;
    esac
done