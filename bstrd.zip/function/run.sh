#!/bin/bash

#==============================================
#▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
#██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
#██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
#▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
#.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
#Cracked By [!]DNThirTeen
#https://www.facebook.com/groups/L34K.C0de/
#==============================================

a=`wc -l 'list/mailist.txt' | awk '{ print $1 }'`
n=`expr "$a" / "99"`
u=`expr "$n" + "1"`
for i in $(seq 1 $u);
do
     if [ ! -s list/mailist.txt ];
    then
            exit
    fi
     php "send.php"
done