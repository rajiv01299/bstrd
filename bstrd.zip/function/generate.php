<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
Cracked By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
Contact Me : g33k@israelmail.com
*/
function RandString($randstr)
{
    $char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $str = "";
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
}
if (file_exists("../users.csv"))
{
    unlink("../users.csv");
}
$fp = fopen("../users.csv", "w");
$fp1 = fopen("generated_user.txt", "w");
fputs($fp, "First Name [Required],Last Name [Required],Email Address [Required],Password [Required]\n");
$total = file_get_contents("user_total.txt");
$domain = file_get_contents("domain.txt");
$domains = explode("\n", $domain);
$domain = $domains[0];
for ($x = 0;$x < $total;$x++)
{
    $user = Randstring(16);
    fputs($fp, "Bastard,User,$user@$domain,11111111\n");
    fputs($fp1, "$user@$domain\n");
}
unlink("domain.txt");
unlink("user_total.txt");
?>
